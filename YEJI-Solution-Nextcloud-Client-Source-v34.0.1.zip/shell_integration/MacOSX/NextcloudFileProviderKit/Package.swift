// swift-tools-version: 6.1
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "NextcloudFileProviderKit",
    platforms: [
        .macOS(.v13)
    ],
    products: [
        // Products define the executables and libraries a package produces, making them visible to other packages.
        .library(
            name: "NextcloudFileProviderKit",
            targets: ["NextcloudFileProviderKit"]
        ),
        .library(
            name: "NextcloudFileProviderXPC",
            targets: ["NextcloudFileProviderXPC"]
        )
    ],
    dependencies: [
        .package(url: "https://github.com/nextcloud/NextcloudCapabilitiesKit.git", from: "2.5.0"),
        .package(url: "https://github.com/nextcloud/NextcloudKit", from: "7.3.3"),
        .package(url: "https://github.com/nicklockwood/SwiftFormat", from: "0.55.0"),
        .package(url: "https://github.com/realm/realm-swift.git", from: "20.0.4")
    ],
    targets: [
        // Targets are the basic building blocks of a package, defining a module or a test suite.
        // Targets can depend on other targets in this package and products from dependencies.
        .target(
            name: "NextcloudFileProviderXPC",
            path: "Sources/NextcloudFileProviderXPC",
            publicHeadersPath: "include"
        ),
        .target(
            name: "NextcloudFileProviderKit",
            dependencies: [
                "NextcloudFileProviderXPC",
                .product(name: "NextcloudCapabilitiesKit", package: "NextcloudCapabilitiesKit"),
                .product(name: "NextcloudKit", package: "NextcloudKit"),
                .product(name: "RealmSwift", package: "realm-swift")
            ],
            resources: [
                .process("Resources")
            ]
        ),
        .target(
            name: "NextcloudFileProviderKitMocks",
            dependencies: [
                "NextcloudFileProviderKit"
            ]
        ),
        .target(
            name: "TestInterface",
            dependencies: [
                "NextcloudFileProviderKit",
                "NextcloudFileProviderKitMocks"
            ],
            path: "Tests/Interface"
        ),
        .testTarget(
            name: "TestInterfaceTests",
            dependencies: ["NextcloudFileProviderKit", "TestInterface"],
            path: "Tests/InterfaceTests"
        ),
        .testTarget(
            name: "NextcloudFileProviderKitTests",
            dependencies: ["NextcloudFileProviderKit", "TestInterface"]
        )
    ]
)
