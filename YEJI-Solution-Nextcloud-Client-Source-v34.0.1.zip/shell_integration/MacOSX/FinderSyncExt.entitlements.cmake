<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>com.apple.security.app-sandbox</key>
	<true/>
	<key>com.apple.security.application-groups</key>
	<array>
		<string>@DEVELOPMENT_TEAM@.@APPLICATION_REV_DOMAIN@</string>
	</array>
@DEBUG_ENTITLEMENTS@
</dict>
</plist>
